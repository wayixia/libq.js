<?php

return array(
  'xmlbook' => dirname(__FILE__).'/../../applications/wayixia/data',
  'wayixia-images' => dirname(__FILE__).'/..'

);

?>
